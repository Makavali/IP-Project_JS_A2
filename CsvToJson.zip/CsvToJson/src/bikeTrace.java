
public class bikeTrace {

//	private int year;
	private int Jan;
	private int Feb;
	private int Mar;
	private int Apr;
	private int May;
	private int June;
	private int July;
	private int Aug;
	private int Sept;
	private int Oct;
	private int Nov;
	private int Dec;
    private String Id;
    private String Name;
    private double latitude;
    private double longitude;
	private int max;
    private int min;
    private int average;
    
    
    public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getAverage() {
		return average;
	}

	public void setAverage(int average) {
		this.average = average;
	}


    
	public int getJan() {
		return Jan;
	}

	public void setJan(int jan) {
		Jan = jan;
	}

	public int getFeb() {
		return Feb;
	}

	public void setFeb(int feb) {
		Feb = feb;
	}

	public int getMar() {
		return Mar;
	}

	public void setMar(int mar) {
		Mar = mar;
	}

	public int getApr() {
		return Apr;
	}

	public void setApr(int apr) {
		Apr = apr;
	}

	public int getMay() {
		return May;
	}

	public void setMay(int may) {
		May = may;
	}

	public int getJune() {
		return June;
	}

	public void setJune(int june) {
		June = june;
	}

	public int getJuly() {
		return July;
	}

	public void setJuly(int july) {
		July = july;
	}

	public int getAug() {
		return Aug;
	}

	public void setAug(int aug) {
		Aug = aug;
	}

	public int getSept() {
		return Sept;
	}

	public void setSept(int sept) {
		Sept = sept;
	}

	public int getOct() {
		return Oct;
	}

	public void setOct(int oct) {
		Oct = oct;
	}

	public int getNov() {
		return Nov;
	}

	public void setNov(int nov) {
		Nov = nov;
	}

	public int getDec() {
		return Dec;
	}

	public void setDec(int dec) {
		Dec = dec;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	
}
