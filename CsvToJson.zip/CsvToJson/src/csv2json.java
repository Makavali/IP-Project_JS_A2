import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



public class csv2json {
	public static String csvFile = "src/data/data_2017_bk.csv";
	public static String csvFileFliter = "src/data/data_2017_filter.csv";
	private static ArrayList<bikeTrace> traceListFilter = new ArrayList<bikeTrace>();
	private static ArrayList<bikeTrace> traceListBasic = new ArrayList<bikeTrace>();
	public static int temp[] = new int[12];
	public static String start = "{ \"data\": ";
	public static String end = "}";
//	private static Context context;
//	public CsvList(Context context){
//        this.context = context;
//    }
	
	public static String tojsonFilter(ArrayList<bikeTrace> tmlist)
			throws IOException {

		@SuppressWarnings("unused")
		JSONObject jsonMonth = new JSONObject();//  create json type data object
		JSONObject jsonObjArr = new JSONObject();
		
		JSONArray jsonArr = new JSONArray();// json type array
		if (tmlist.size() > 0) {
			for (int i = 0; i < tmlist.size(); i++) {
				if (tmlist.get(i).getJan() != 0||
						tmlist.get(i).getFeb() != 0||
						tmlist.get(i).getMar() != 0||
						tmlist.get(i).getApr() != 0||
						tmlist.get(i).getMay() != 0||
						tmlist.get(i).getJune() != 0||
						tmlist.get(i).getJuly() != 0||
						tmlist.get(i).getAug() != 0||
						tmlist.get(i).getSept() != 0||
						tmlist.get(i).getOct() != 0||
						tmlist.get(i).getNov() != 0||
						tmlist.get(i).getDec() != 0) {
					jsonMonth.put("Jan",tmlist.get(i).getJan());
					jsonMonth.put("Feb",tmlist.get(i).getFeb());
					jsonMonth.put("Mar",tmlist.get(i).getMar());
					jsonMonth.put("Apr",tmlist.get(i).getApr());
					jsonMonth.put("May",tmlist.get(i).getMay());
					jsonMonth.put("Jun",tmlist.get(i).getJune());
					jsonMonth.put("July",tmlist.get(i).getJuly());
					jsonMonth.put("Aug",tmlist.get(i).getAug());
					jsonMonth.put("Sept",tmlist.get(i).getSept());
					jsonMonth.put("Oct",tmlist.get(i).getOct());
					jsonMonth.put("Nov",tmlist.get(i).getNov());
					jsonMonth.put("Dec",tmlist.get(i).getDec());
					
					jsonObjArr.put("kv", jsonMonth);
				}
				if (tmlist.get(i).getId() != null) {

					jsonObjArr.put("id", tmlist.get(i).getId());
				}
				if (tmlist.get(i).getName() != null) {

					jsonObjArr.put("name", tmlist.get(i).getName());
				}
				if (tmlist.get(i).getLongitude() != 0
						&& tmlist.get(i).getLatitude() != 0) {

					jsonObjArr.put("location", "[" + tmlist.get(i).getLongitude() + ","
							+ tmlist.get(i).getLatitude() + "]");
				}
				
				jsonObjArr.put("min", tmlist.get(i).getMin());
				jsonObjArr.put("max", tmlist.get(i).getMax());
				jsonObjArr.put("average", tmlist.get(i).getAverage());
				
				//put json data into json array
				jsonArr.add(jsonObjArr);

			}
		}

		// System.out.println(format(jsonArr.toString()));
		@SuppressWarnings("unused")
		String path1 = "src/data/tracejson_1.json";
		String path2 = "src/data/tracejson_2.json";
		writejsonfile(path2,start.concat(jsonArr.toString()).concat(end));
		System.out.println(start.concat(jsonArr.toString()).concat(end));
		System.out.println("Done Writing!");
		return jsonArr.toString();
	}
	
	
	public static void writejsonfile(String filePath, String sets)
			throws IOException {
		// FileWriter fw = new FileWriter(filePath);
//		System.out.println(filePath);
		OutputStreamWriter outstream = new OutputStreamWriter(
				new FileOutputStream(filePath), "utf-8");
		PrintWriter out = new PrintWriter(outstream);

		out.write(sets);

		out.println();
		// fw.close();
		out.close();
	}
	
	/**
	 * This method is used for parsing csv file,
	 * then put different value in arraylist
	 * @param ArrayList<bikeTrace> 
	 * This arraylist holds relative value
	*/
	public static void parseCsvFilter(ArrayList<bikeTrace> traceList) throws IOException{
		File csv = new File(csvFileFliter);
		BufferedReader br = null;
		    try
		    {
		        br = new BufferedReader(new FileReader(csv));
		    } catch (FileNotFoundException e)
		    {
		        e.printStackTrace();
		    }
		    String line = "";
		    String everyLine = "";
		    int count= 0;
		    try {
		            List<String> allString = new ArrayList<>();
		            while ((line = br.readLine()) != null)
		            {
		            	if(count>=1){
		            	everyLine = line;
		                allString.add(everyLine);
		            	}
		               
		            count++;
		            }
	       for (int i = 0; i < allString.size(); i++) {  
	    	   bikeTrace trace = new bikeTrace();
	    	   		// use get(int index) method get the objects in directed index location
                 	String s[]= allString.get(i).split(",");
//                 	System.out.println(s.length);
                 	transArr(temp, s);
                 	trace.setId(s[0]);
                 	trace.setJan(Integer.parseInt(s[1]));
                 	trace.setFeb(Integer.parseInt(s[2]));
                 	trace.setMar(Integer.parseInt(s[3]));
                 	trace.setApr(Integer.parseInt(s[4]));
                 	trace.setMay(Integer.parseInt(s[5]));
                 	trace.setJune(Integer.parseInt(s[6]));
                 	trace.setJuly(Integer.parseInt(s[7]));
                 	trace.setAug(Integer.parseInt(s[8]));
                 	trace.setSept(Integer.parseInt(s[9]));
                 	trace.setOct(Integer.parseInt(s[10]));
                 	trace.setNov(Integer.parseInt(s[11]));
                 	trace.setDec(Integer.parseInt(s[12]));
                 	trace.setName(s[13]);
                 	trace.setLongitude(Double.valueOf(s[14]));
                 	trace.setLatitude(Double.valueOf(s[15]));
                 	
                 	trace.setMax(max(temp));
                 	trace.setMin(min(temp));
                 	trace.setAverage(average(temp));
                 	
                 	traceList.add(trace);
	                 }  
		    } catch (IOException e)
		    {
		        e.printStackTrace();
		    }
	}
	
	
	
	public static String tojsonBasic(ArrayList<bikeTrace> tmlist)
			throws IOException {

		@SuppressWarnings("unused")
		JSONObject jsonMonth = new JSONObject();// create json type data object
		JSONObject jsonObjArr = new JSONObject();
		
		JSONArray jsonArr = new JSONArray();// json type array
		//judging if the data is null
		if (tmlist.size() > 0) {
			for (int i = 0; i < tmlist.size(); i++) {
				if (tmlist.get(i).getId() != null) {

					jsonObjArr.put("id", tmlist.get(i).getId());
				}
				if (tmlist.get(i).getName() != null) {

					jsonObjArr.put("name", tmlist.get(i).getName());
				}
				if (tmlist.get(i).getLongitude() != 0
						&& tmlist.get(i).getLatitude() != 0) {

					jsonObjArr.put("location", "[" + tmlist.get(i).getLongitude() + ","
							+ tmlist.get(i).getLatitude() + "]");
				}
				
				jsonObjArr.put("min", tmlist.get(i).getMin());
				jsonObjArr.put("max", tmlist.get(i).getMax());
				jsonObjArr.put("average", tmlist.get(i).getAverage());
				
				//put json data into json array
				jsonArr.add(jsonObjArr);

			}
		}

		// System.out.println(format(jsonArr.toString()));
		@SuppressWarnings("unused")
		String path1 = "src/data/tracejson_1.json";
		String path2 = "src/data/tracejson_2.json";
		writejsonfile(path1,start.concat(jsonArr.toString()).concat(end));
		System.out.println(start.concat(jsonArr.toString()).concat(end));
		System.out.println("Done Writing!");
		return jsonArr.toString();
		
	}
	
	
	/**
	 * This method is used for parsing csv file,
	 * then put different value in arraylist
	 * @param ArrayList<bikeTrace> 
	 * This arraylist holds relative value
	*/
	public static void parseCsvBasic(ArrayList<bikeTrace> traceList) throws IOException{
		File csv = new File(csvFile);
		BufferedReader br = null;
		    try
		    {
		        br = new BufferedReader(new FileReader(csv));
		    } catch (FileNotFoundException e)
		    {
		        e.printStackTrace();
		    }
		    String line = "";
		    String everyLine = "";
		    int count= 0;
		    try {
		            List<String> allString = new ArrayList<>();
		            while ((line = br.readLine()) != null)
		            {
		            	if(count>=1){
		            	everyLine = line;
		                allString.add(everyLine);
		            	}
		               
		            count++;
		            }
	       for (int i = 0; i < allString.size(); i++) {  
	    	   bikeTrace trace = new bikeTrace();
	    	   		// use get(int index) method get the objects in directed index location
                 	String s[]= allString.get(i).split(",");
//                 	System.out.println(s.length);
                 	transArr(temp, s);
                 	trace.setId(s[0]);
                 	trace.setName(s[13]);
                 	trace.setLongitude(Double.valueOf(s[14]));
                 	trace.setLatitude(Double.valueOf(s[15]));
                 	trace.setMax(max(temp));
                 	trace.setMin(min(temp));
                 	trace.setAverage(average(temp));
                 	
                 	traceList.add(trace);
	                 }  
		    } catch (IOException e)
		    {
		        e.printStackTrace();
		    }
	}
	
//	transfer a string array into int array	
	public static void transArr(int arr1[],String arr2[]){
		for(int i=0;i<arr1.length;i++){
			arr1[i] = Integer.parseInt(arr2[i+1]);
		}
	}
//	return the max num in an array
	public static int max(int arr[]){
		int j=arr[0];
		for(int i=1;i<arr.length;i++){
			 if(arr[i]>j){  
	                j = arr[i];  
	            }  
		}
		return j;
		
	}
//	return the min num in an array	
	public static int min(int arr[]){
		int j=arr[0];
		for(int i=1;i<arr.length;i++){
			 if(arr[i]<j){  
	                j = arr[i];  
	            }  
		}
		return j;
		
	}
//	return the arverage of an int array	
	public static int average(int arr[]){
		int sum =0;
		for(int i=0;i<arr.length;i++){
			sum = sum+arr[i];
		}
		return sum/12;
	}

	public static void main(String[] args) throws FileNotFoundException, IOException {
		//read filter information from csv file and write to json file
			parseCsvFilter(traceListFilter);
			tojsonFilter(traceListFilter);
		//read basic information from csv file and write to json file
			parseCsvBasic(traceListBasic);
			tojsonBasic(traceListBasic);
	}

}
