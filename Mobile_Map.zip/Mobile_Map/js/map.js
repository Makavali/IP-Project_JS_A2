//center of Boston
var center = ol.proj.transform([-71.05783, 42.36301], 'EPSG:4326', 'EPSG:3857');
var state = 0;
var marker; // global so we can remove it later
var source = new ol.source.Vector({
	wrapX: false
});
var vector = new ol.layer.Vector({
	//		title:'Point',
	source: source
});
//var cordinate;
var curlati = null;
var curlong = null;
var currentposition = null;
var basemap = new ol.layer.Tile({
	source: new ol.source.OSM()
});

//key of Bing map 
var bk = 'ApTJzdkyN1DdFKkRAE6QIDtzihNaf6IWJsT-nQ_2eMoO4PN__0Tzhl2-WgJtXFSp';

//2 controls used for control heatmap blur and radius
var blur = document.getElementById('blur');
var radius = document.getElementById('radius');

//Base map group, made of three base maps: OSM, water color map and water color with labels
var BasemapGroup = new ol.layer.Group({
	'title': 'Base maps',
	layers: [
		new ol.layer.Group({
			title: 'Water color with labels',
			type: 'base',
			combine: true,
			visible: false,
			layers: [
				new ol.layer.Tile({
					source: new ol.source.Stamen({
						layer: 'watercolor'
					})
				}),
				new ol.layer.Tile({
					source: new ol.source.Stamen({
						layer: 'terrain-labels'
					})
				})
			]
		}),
		new ol.layer.Tile({
			title: 'Water color',
			type: 'base',
			visible: false,
			source: new ol.source.Stamen({
				layer: 'watercolor'
			})
		}),
		new ol.layer.Tile({
			title: 'OSM',
			type: 'base',
			visible: true,
			source: new ol.source.OSM()
		})
	]
}); //BasemapGroup

//Bing map group, made of three base maps: Road, RoadOnDemand map and Aerial and AerialWithLabels
var BingMapGroup = new ol.layer.Group({
	'title': 'Bing maps',
	layers: [
		new ol.layer.Tile({
			title: 'AerialWithLabels',
			type: 'base',
			visible: false,
			preload: Infinity,
			source: new ol.source.BingMaps({
				key: bk,
				imagerySet: 'AerialWithLabels'
			})
		}),
		new ol.layer.Tile({
			title: 'Aerial',
			type: 'base',
			visible: false,
			preload: Infinity,
			source: new ol.source.BingMaps({
				key: bk,
				imagerySet: 'Aerial'
			})
		}),
		new ol.layer.Tile({
			title: 'RoadOnDemand',
			type: 'base',
			visible: false,
			preload: Infinity,
			source: new ol.source.BingMaps({
				key: bk,
				imagerySet: 'RoadOnDemand'
			})
		}),
		new ol.layer.Tile({
			title: 'Road',
			type: 'base',
			visible: false,
			preload: Infinity,
			source: new ol.source.BingMaps({
				key: bk,
				imagerySet: 'Road'
			})
		})
	]
})//BingMapGroup

//heatmap of distribution of bike station in Boston 
var heatVector = new ol.layer.Heatmap({
	title: 'HeatMap',
// 'base' determines whether it is a base map or a overlay map
//	type: 'base',  
	visible: true,
	source: new ol.source.Vector({
//		read from kml file
		url: 'data/BikeStation.kml',
		format: new ol.format.KML({
			extractStyles: false,
			showPointNames: true
		})
	}),
	blur: parseInt(blur.value, 10),
	radius: parseInt(radius.value, 10)
});//heatmap


heatVector.getSource().on('addfeature', function(event) {
	var name = event.feature.get('name');
	var level = parseFloat(name.substr(name.indexOf("#")));
	event.feature.set('weight', level + 5);
});

var basicinfoVectorLayer = new ol.layer.Vector({
	title: 'Basic Info',
	visible: false,
});

var diagramVectorLayer = new ol.layer.Vector({
	title: 'Diagram',
	visible: false,
});
//diagramVectorLayer.set('id', 'diagram');

//vector layers group, made of 3 layers: heatmap, basicinformation and diagram
var VectorGroup = new ol.layer.Group({
	title: 'Vector',
	//      type: 'base',
	//      visible: false,
	layers: [
		 heatVector, basicinfoVectorLayer, diagramVectorLayer
	]
});//vector layers group



var map = new ol.Map({

	layers: [

		BasemapGroup,
		BingMapGroup,
		VectorGroup
	],
	target: 'map',
	controls: ol.control.defaults({
		attributionOptions: {
			collapsible: false
		}

	}),
	controls: ol.control.defaults().extend([
		new ol.control.OverviewMap({}),
		new ol.control.Rotate({
			autoHide: false
		}),
		new ol.control.FullScreen(),
		new ol.control.ScaleLine({})
	]),

	view: new ol.View({
		center: center,
		projection: 'EPSG:3857',
		zoom: 12
	})
});

//setting Boston's center feature
var iconFeature = new ol.Feature({
	geometry: new ol.geom.Point(center),
	name: 'Boston city\'s center.'
});
iconFeature.setId(1);
var iconStyle1 = new ol.style.Style({
	image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
		scale: 0.6,
		anchor: [0.5, 46],
		anchorXUnits: 'fraction',
		anchorYUnits: 'pixels',
		src: 'img/marker3.png'
	}))
});

iconFeature.setStyle(iconStyle1);
var vectorSource = new ol.source.Vector({
	features: [iconFeature]
});

var vectorLayer = new ol.layer.Vector({
	source: vectorSource
});
map.addLayer(vectorLayer);


//basic information feature collection
var featuresBasic = new ol.Collection({

});
//diagram feature collection
var featuresDiagram = new ol.Collection({

});

//these 2 variables stands for data in json file, used for distinguishing different features 
var basicKV;
var filterKV;
//add popup for each point    
$.getJSON('data/tracejson_1.json', function(data) {
	$.each(data.data, function(i, val) {
		var basicinfoFeature = new ol.Feature({
			geometry: new ol.geom.Point(ol.proj.transform(val.location, 'EPSG:4326', 'EPSG:3857')),
			name: val.name,
			id: val.id,
			min: val.min,
			max: val.max,
			Average: val.average,
			population: 4000,
			rainfall: 500
		});

		var iconStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.5, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				src: 'img/marker-icon.png'
			}))
		});
		
		
		var highStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/mark_high.png'
			}))
		});//highStyle
		var midStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/mark_mid.png'
			}))
		});//midStyle
		var lowStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/mark_low.png'
			}))
		});//lowStyle
		
//				using different icon to display points according to different data ranges
//				average<1000 : blue icon
//				1000<average<2000 : green icon
//				average>2000 :red icon
		if(val.average < 1000) {
			basicinfoFeature.setStyle(lowStyle);
		} else if(val.average < 2000 && val.average > 1000) {
			basicinfoFeature.setStyle(midStyle);
		} else
			basicinfoFeature.setStyle(highStyle);

		featuresBasic.push(basicinfoFeature);

		basicKV = val.kv;

		var element = document.getElementById('popup');
		var popup = new ol.Overlay({
			element: element,
			positioning: 'bottom-center',
			stopEvent: false,
			offset: [0, -50]
		});
		map.addOverlay(popup);

		basicKV = val.kv;
		if(basicKV == undefined) {
			// display popup on click
			map.on('click', function(evt) {
				var feature = map.forEachFeatureAtPixel(evt.pixel,
					function(feature) {
						if(feature.get('Average') != undefined)
							return feature;
					});
				if(feature) {
					var coordinates = feature.getGeometry().getCoordinates();
					popup.setPosition(coordinates);
					var feature_name = feature.get('name');
					var feature_id = feature.get('id');
					var feature_max = feature.get('max');
					var feature_min = feature.get('min');
					var feature_average = feature.get('Average');
//					popup setting(content,position and type, etc.)
					$(element).popover({
						placement: 'top',
						html: true,
						title: feature_name,
						content: "<p style=\"width: 200px;\">ID: " + feature_id + "</p>" +
							"<p style=\"width: 200px;\">Max: " + feature_max + "</p>" +
							"<p style=\"width: 200px;\">Min: " + feature_min + "</p>" +
							"<p style=\"width: 200px;\">Average: " + feature_average + "</p>"
					});

					$(element).popover('show');
				} else {
					$(element).popover('destroy');
				}
			});

			// change mouse cursor when over marker
			map.on('pointermove', function(e) {
				if(e.dragging) {
					$(element).popover('destroy');
					return;
				}
				var pixel = map.getEventPixel(e.originalEvent);
				var hit = map.hasFeatureAtPixel(pixel);
				map.getTargetElement().style.cursor = hit ? 'pointer' : '';
			});
		}
	})
});
//set feature to vector source
var basicinfoVectorSource = new ol.source.Vector({
	features: featuresBasic
});
//set vector source to vector layer
basicinfoVectorLayer.setSource(basicinfoVectorSource);


//add diagram for each point,get data from json file and visualization
$.getJSON('data/tracejson_2.json', function(data) {
	$.each(data.data, function(i, val) {
		var basicinfoFeature = new ol.Feature({
			geometry: new ol.geom.Point(ol.proj.transform(val.location, 'EPSG:4326', 'EPSG:3857')),
			name: val.name,
			id: val.id,
			
//			12 months data  
			value1: val.kv.Jan,
			value2: val.kv.Feb,
			value3: val.kv.Mar,
			value4: val.kv.Apr,
			value5: val.kv.May,
			value6: val.kv.Jun,
			value7: val.kv.July,
			value8: val.kv.Aug,
			value9: val.kv.Sept,
			value10: val.kv.Oct,
			value11: val.kv.Nov,
			value12: val.kv.Dec,
//			12 months data  

			min: val.min,
			max: val.max,
			average: val.average,
			population: 4000,
			rainfall: 500
		});

		var iconStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.5, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				src: 'img/marker-icon.png'
			}))
		});
		
//		this style stands for average frequency higher than 1100 times station
		var highStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/pie.png'
			}))
		});//highstyle
		
//		this style stands for average frequency in the range of (750,1100) times station
		var midStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.2,
				src: 'img/rose.png'
			}))
		});//midstyle
		
//		this style stands for average frequency in the range of (550,750) times station		
		var lowStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/line.png'
			}))
		});//lowstyle
		
//		this style stands for average frequency lower than 550 times station		
		var smallStyle = new ol.style.Style({
			image: new ol.style.Icon( /** @type {olx.style.IconOptions} */ ({
				anchor: [0.1, 46],
				anchorXUnits: 'fraction',
				anchorYUnits: 'pixels',
				scale: 0.16,
				src: 'img/bar.png'
			}))
		});//smallstyle

//		setting different style to features
		if(val.average < 550) {
			basicinfoFeature.setStyle(smallStyle);
		} else if(val.average < 750 && val.average > 550) {
			basicinfoFeature.setStyle(lowStyle);
		} else if(val.average < 1100 && val.average > 750) {
			basicinfoFeature.setStyle(midStyle);
		} else
			basicinfoFeature.setStyle(highStyle);
			
//		add every feature in feature collection
		featuresDiagram.push(basicinfoFeature);

		var element = document.getElementById('diagram');
		var popup = new ol.Overlay({
			element: element,
			positioning: 'bottom-center',
			stopEvent: false,
			offset: [0, -50]
		});
		map.addOverlay(popup);

		filterKV = val.kv;
		if(basicKV == undefined && filterKV != undefined) {

			// display popup on click
			map.on('click', function(evt) {
				var feature = map.forEachFeatureAtPixel(evt.pixel,
					function(feature) {
						if(feature.get('id') != undefined)
							return feature;
					});
				if(feature) {
					var coordinates = feature.getGeometry().getCoordinates();
					popup.setPosition(coordinates);
					var feature_name = feature.get('name');
					var feature_id = feature.get('id');
					var feature_max = feature.get('max');
					var feature_min = feature.get('min');
					var feature_average = feature.get('average');
					
//				according to different average value set different diagram, respectively like follow:
//				average<550 : Histogram(Bar chart)
//				550<average<750 : Line chart
//				750<average<1100 :Rose chart
//				average>1100 : Pie chart
					if(feature.get('average') < 550) {
						$(element).popover({
							placement: 'top',
							html: true,
							title: feature_name,
							content: "<div id=marker" + feature.get('id') + " " + "style=\"width:300px; height:240px; background:white;\"></div>"
						});

						$(element).popover('show');
						var myChart = echarts.init(document.getElementById('marker' + feature.get('id')));
						// Specify the configuration items and data for the chart
						option = {
							tooltip: {
								trigger: 'axis'
							},
							grid: {
								x: '20%',
								y: '20%',
								x2: 2,
								y2: '12%'
							},
							xAxis: [{
								type: 'category',
								data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
							}],
							yAxis: [{
								type: 'value',
								name: 'Frequency',
								min: 0,
								max: 800,

							}],
							series: [{
								name: 'Frequency',
								type: 'bar',
								barCategoryGap: '5%',
								data: [feature.get('value1'),
									feature.get('value2'),
									feature.get('value3'),
									feature.get('value4'),
									feature.get('value5'),
									feature.get('value6'),
									feature.get('value7'),
									feature.get('value8'),
									feature.get('value9'),
									feature.get('value10'),
									feature.get('value11'),
									feature.get('value12')
								]
							}]
						};
						// Use the configuration item and data just specified to display the chart
						myChart.setOption(option);
					} else if(feature.get('average') < 750 && feature.get('average') > 550) {
						$(element).popover({
							placement: 'top',
							html: true,
							title: feature_name,
							content: "<div id=marker" + feature.get('id') + " " + "style=\"width:300px; height:240px; background:white;\"></div>"
						});

						$(element).popover('show');
						var myChart = echarts.init(document.getElementById('marker' + feature.get('id')));
						// Specify the configuration items and data for the chart
						option = {
							tooltip: {
								trigger: 'axis'
							},
							grid: {
								x: '20%',
								y: '20%',
								x2: 2,
								y2: '12%'
							},
							xAxis: [{
								type: 'category',
								data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
							}],
							yAxis: [{
								type: 'value',
								name: 'Frequency',
								min: 0,
								max: 1500,
							}],
							series: [{
								name: 'Frequency',
								type: 'line',
								barCategoryGap: '5%',
								data: [feature.get('value1'),
									feature.get('value2'),
									feature.get('value3'),
									feature.get('value4'),
									feature.get('value5'),
									feature.get('value6'),
									feature.get('value7'),
									feature.get('value8'),
									feature.get('value9'),
									feature.get('value10'),
									feature.get('value11'),
									feature.get('value12')
								]
							}]
						};
						// Use the configuration item and data just specified to display the chart
						myChart.setOption(option);
					} else if(feature.get('average') < 1100 && feature.get('average') > 750) {
						$(element).popover({
							placement: 'top',
							html: true,
							title: feature_name,
							content: "<div id=marker" + feature.get('id') + " " + "style=\"width:425px; height:315px; background:white;\"></div>"
						});
						$(element).popover('show');
						var myChart = echarts.init(document.getElementById('marker' + feature.get('id')));
						var option = {
							tooltip: {
								trigger: 'item',
								formatter: "{a} <br/>{b} : {c} ({d}%)"
							},
							calculable: true,
							series: [{
								name: 'Frequency',
								type: 'pie',
								radius: [30, 120],
								center: ['50%', '50%'], //relative position of chart's center compare to the container 
								roseType: 'area', //area mode 
								itemStyle: {
									normal: {

										label: { // the label text Indicated to the module  
											show: true,
											color: 'black',
											formatter: '{b} : {c} \n ({d}%)'
										},
										labelLine: { // the labelLine Indicated to the module  
											show: true,

										}
									},
								},

								color: ['#a6cee3', '#1f78b4', '#b2df8a', '#33a02c', '#fb9a99', '#e31a1c', '#fdbf6f', '#ff7f00', '#cab2d6', '#6a3d9a', 'black', '#b15928'], //颜色将根据饼图的区域个数循环  
								data: [{
										value: feature.get('value1'),
										name: 'Jan'
									},
									{
										value: feature.get('value2'),
										name: 'Feb'
									},
									{
										value: feature.get('value3'),
										name: 'Mar'
									},
									{
										value: feature.get('value4'),
										name: 'Apr'
									},
									{
										value: feature.get('value5'),
										name: 'May'
									},
									{
										value: feature.get('value6'),
										name: 'June'
									},
									{
										value: feature.get('value7'),
										name: 'July'
									},
									{
										value: feature.get('value8'),
										name: 'Aug'
									},
									{
										value: feature.get('value9'),
										name: 'Sept'
									},
									{
										value: feature.get('value10'),
										name: 'Oct'
									},
									{
										value: feature.get('value11'),
										name: 'Nov'
									},
									{
										value: feature.get('value12'),
										name: 'Dec'
									}
								],

							}]
						};
						myChart.setOption(option);
					} else if(feature.get('average') > 1100) {
						$(element).popover({
							placement: 'top',
							html: true,
							title: feature_name,
							content: "<div id=marker" + feature.get('id') + " " + "style=\"width:300px; height:240px; background:white;\"></div>"
						});

						$(element).popover('show');
						var myChart = echarts.init(document.getElementById('marker' + feature.get('id')));
						option = {
							backgroundColor: '#2c343c',
							tooltip: {
								trigger: 'item',
								formatter: "{a} <br/>{b} : {c} ({d}%)"
							},
							series: [{
								name: 'Frequency',
								type: 'pie',
								radius: '80%',
								center: ['50%', '50%'],
								data: [{
										value: feature.get('value1'),
										name: 'Jan'
									},
									{
										value: feature.get('value2'),
										name: 'Feb'
									},
									{
										value: feature.get('value3'),
										name: 'Mar'
									},
									{
										value: feature.get('value4'),
										name: 'Apr'
									},
									{
										value: feature.get('value5'),
										name: 'May'
									},
									{
										value: feature.get('value6'),
										name: 'June'
									},
									{
										value: feature.get('value7'),
										name: 'July'
									},
									{
										value: feature.get('value8'),
										name: 'Aug'
									},
									{
										value: feature.get('value9'),
										name: 'Sept'
									},
									{
										value: feature.get('value10'),
										name: 'Oct'
									},
									{
										value: feature.get('value11'),
										name: 'Nov'
									},
									{
										value: feature.get('value12'),
										name: 'Dec'
									}
								].sort(function(a, b) {
									return a.value - b.value;
								}),
								roseType: 'radius',
								label: {
									normal: {
										textStyle: {
											color: 'rgba(255, 255, 255, 0.3)'
										}
									}
								},
								labelLine: {
									normal: {
										lineStyle: {
											color: 'rgba(255, 255, 255, 0.3)'
										},
										smooth: 0.2,
										length: 10,
										length2: 20
									}
								},
								itemStyle: {
									normal: {
										color: '#c23531',
										shadowBlur: 200,
										shadowColor: 'rgba(0, 0, 0, 0.5)'
									}
								},

								animationType: 'scale',
								animationEasing: 'elasticOut',
								animationDelay: function(idx) {
									return Math.random() * 200;
								}
							}]
						};
						myChart.setOption(option);
					}
				} else {
					$(element).popover('destroy');
				}

			});

			// change mouse cursor when over marker
			map.on('pointermove', function(e) {
				if(e.dragging) {
					$(element).popover('destroy');
					return;
				}
				var pixel = map.getEventPixel(e.originalEvent);
				var hit = map.hasFeatureAtPixel(pixel);
				map.getTargetElement().style.cursor = hit ? 'pointer' : '';
			});
		}
	})
});

//set feature to vector source
var diagramVectorSource = new ol.source.Vector({
	features: featuresDiagram
});
//set vector source to vector layer
diagramVectorLayer.setSource(diagramVectorSource);

//add layerswitcher control in map
var layerSwitcher = new ol.control.LayerSwitcher({
	tipLabel: 'Légende' // Optional label for button
});
map.addControl(layerSwitcher);




//creat the lable's style  
function createLabel(feature) {
	return new ol.style.Style({
		image: new ol.style.Icon({
			//scale of img
			scale: 0.5,
			//control label distance between img and text
			anchor: [0.5, 60],
			//lable style original position  
			anchorOrigin: 'top-right',
			//X direction unit: fraction  
			anchorXUnits: 'fraction',
			//Y direction unit: pixels
			anchorYUnits: 'pixels',
			//Offset direction of the starting point  
			offsetOrigin: 'top-right',
			//opacity  
			opacity: 0.75,
			//path of img  
			src: 'img/marker2.png'
		}),
		//text style  
		text: new ol.style.Text({
			//align style  
			textAlign: 'center',
			//text baseline  
			textBaseline: 'middle',
			//font style  
			font: 'normal 14px 微软雅黑',
			//text content 
			//text: feature.get('name'),  
			text: '',
			//fill style  
			fill: new ol.style.Fill({
				color: '#aa3300'
			}),
			//stroke  
			stroke: new ol.style.Stroke({
				color: '#ffcc33',
				width: 2
			})
		})
	});
}

//Add the points as feature on the map
function addMarker(cordinate, string) {
	var newFeature = new ol.Feature({
		geometry: new ol.geom.Point(cordinate),
		name: cordinate
	});
	//set the marker style 
	if(string == true) {
		newFeature.setStyle(createLabel(newFeature));
		//Add the current feature to the vector data source  
		vectorSource.addFeature(newFeature);
	}

}

document.getElementById('zoom-out').onclick = function() {
	var view = map.getView();
	var zoom = view.getZoom();
	view.setZoom(zoom - 1);
};

document.getElementById('zoom-in').onclick = function() {
	var view = map.getView();
	var zoom = view.getZoom();
	view.setZoom(zoom + 1);
};

document.getElementById('clear').onclick = function() {
	vectorSource.clear();
};

document.getElementById('center').onclick = function() {
	if(vectorSource.getFeatureById(1) == null) {
		vectorSource.addFeature(iconFeature);
	} else
		console.log("The center point is already exist!")
};


//Add listener event for point radius, dynamically set point radius
blur.addEventListener('input', function() {
	heatVector.setBlur(parseInt(blur.value, 10));
});
//Add listeners event for fuzzy dimensions,dynamically set blur dimensions
radius.addEventListener('input', function() {
	heatVector.setRadius(parseInt(radius.value, 10));
});

//enable the map clicking and marking
function enableMark() {
	
	var checkBox = document.getElementById("checkmark");
	if(checkBox.checked == true) {
			console.log("Checkbox is checked,now the map is markable!");
		map.on('click', function(evt) {
			var type = $('input[name="label"]:checked').val();
			var point = evt.coordinate;
			addMarker(point, checkBox.checked);
		});

	} else {
		map.on('click', function(evt) {
				console.log("Checkbox is unchecked,now the map is un-markable!")
		});
	}
}